# Talyllyn Railway - Multi-Step Membership Form

A responsive, multi-step membership application and renewal form built with HTML5, CSS3, Bootstrap 5, jQuery, and jQuery UI.

## Features

### Step 1: Membership Selection
- Display of membership classes with pricing
- Dynamic member table for adding multiple family members
- Date picker integration for date of birth fields
- Automatic price calculation based on membership class
- Donation field with optional Gift Aid
- Real-time total calculation
- Renewal checkbox option

### Step 2: Direct Debit Details
- Personal information collection (Title, Name)
- Contact details validation (Phone, Email with confirmation)
- Address information with postcode lookup placeholder
- Bank details input with formatted sort code (XX-XX-XX)
- Real-time form validation
- Visual feedback for valid/invalid fields

### Step 3: Confirmation
- Thank you message
- Success confirmation with visual feedback
- Professional completion screen

## Technologies Used

- **HTML5** - Semantic markup and structure
- **CSS3** - Custom styling with animations and transitions
- **Bootstrap 5.3.0** - Responsive grid system and components
- **jQuery 3.6.0** - DOM manipulation and event handling
- **jQuery UI 1.13.2** - Datepicker widget for date fields
- **Font Awesome 6.4.0** - Icons

## File Structure

```
membership-form/
│
├── membership-form.html    # Main HTML file
├── styles.css              # Custom CSS styles
├── script.js               # JavaScript functionality
├── logo.png                # Talyllyn Railway logo
└── README.md               # This file
```

## Key Features

### Responsive Design
- **Desktop** (>1024px): Full-width table layout with all columns visible
- **Tablet** (768px - 1024px): Optimized spacing and font sizes
- **Mobile** (<768px): Horizontal scrolling for member table, stacked form layout

### Form Validation
- Required field validation
- Email format and confirmation matching
- Phone number format validation
- Sort code format (6 digits, XX-XX-XX)
- Account number validation (8 digits)
- Real-time feedback with visual indicators

### Dynamic Features
- Add unlimited family members
- Auto-calculate membership amounts
- Real-time total calculation including donations
- Datepicker with year range 1900-current year
- Auto-advance for sort code inputs
- Smooth animations and transitions

### User Experience Enhancements
- Progress indicator showing current step
- Form field auto-formatting (postcode uppercase, numbers only for bank details)
- Smooth scrolling between sections
- Loading states for form submission
- Clear error messages
- Visual validation feedback (green checkmarks)

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Installation & Usage

1. **Extract Files**: Unzip the project folder

2. **Open in Browser**: 
   - Simply open `membership-form.html` in any modern web browser
   - No server setup required for basic functionality

3. **Customize**:
   - Update logo by replacing `logo.png`
   - Modify colors in `styles.css` (primary color: #00577B, accent: #c41e3a)
   - Adjust membership prices in `script.js` (membershipPrices object)

## Customization Guide

### Colors
Main brand colors are defined in CSS:
- **Primary Blue**: `#00577B` (headers, buttons)
- **Accent Red**: `#c41e3a` (prices, highlights)
- **Success Green**: `#28a745` (validation)

### Membership Prices
Edit the `membershipPrices` object in `script.js`:
```javascript
const membershipPrices = {
    'ordinary-25': 25,
    'senior-20': 20,
    // Add or modify as needed
};
```

### Form Fields
- Add/remove fields in HTML
- Update validation in `validateStep1()` and `validateStep2()` functions
- Modify required fields list in JavaScript

## Responsive Breakpoints

- **Desktop**: 1024px and above
- **Tablet**: 768px - 1023px
- **Mobile**: Below 768px
- **Small Mobile**: Below 576px

## Accessibility Features

- Semantic HTML5 elements
- ARIA labels where appropriate
- Keyboard navigation support
- Focus indicators on form fields
- High contrast for text readability
- Form field labels properly associated

## Form Validation Rules

### Step 1
- At least one member must be added
- All member fields must be filled (Title, Forename, Surname, Membership Class)
- Total amount must be greater than £0

### Step 2
- All required fields must be filled
- Email must be valid format
- Email confirmation must match
- Contact number must be valid (10+ characters)
- Sort code must be 6 digits (XX-XX-XX format)
- Account number must be exactly 8 digits
- Postcode required

## Future Enhancements

Potential improvements:
- Backend integration for form submission
- Payment gateway integration
- Email confirmation system
- PDF generation of application
- Save progress functionality
- Multi-language support
- Print stylesheet optimization
- Advanced postcode lookup API integration

## Known Limitations

- Form submission is simulated (no backend)
- Postcode lookup "Find" button is placeholder
- Member removal functionality not implemented
- No persistent data storage

## Testing Checklist

- [x] Form loads correctly on all devices
- [x] All steps navigate properly
- [x] Datepicker works on all date fields
- [x] Dynamic member rows add correctly
- [x] Price calculation is accurate
- [x] Validation catches all required fields
- [x] Email validation and matching works
- [x] Sort code auto-advances correctly
- [x] Account number accepts only 8 digits
- [x] Responsive layout works on mobile
- [x] Table scrolls horizontally on small screens
- [x] Progress indicator updates correctly
- [x] Success page displays after completion

## Credits

**Design**: Based on Talyllyn Railway Preservation Society membership forms
**Development**: Custom implementation with Bootstrap 5 and jQuery
**Icons**: Font Awesome
**Datepicker**: jQuery UI

## License

This is a demonstration project. Please ensure proper licensing for production use.

## Support

For issues or questions:
1. Check this README
2. Review the inline code comments
3. Test in different browsers
4. Check browser console for JavaScript errors

## Version History

- **v1.0** (2026-02-10)
  - Initial release
  - Three-step form implementation
  - Full responsive design
  - Form validation
  - Datepicker integration
  - Dynamic member management

---

**Last Updated**: February 10, 2026
