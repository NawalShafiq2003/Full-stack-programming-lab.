$(document).ready(function() {
    let currentStep = 1;
    const totalSteps = 3;

    // Show form container and hide landing on start button click
    $('#startBtn').on('click', function() {
        $('.landing-screen').removeClass('active');
        $('.form-container').addClass('active');
        $('html, body').animate({ scrollTop: 0 }, 300);
    });

    // Initialize datepicker for date of birth fields
    function initializeDatepickers() {
        $('.datepicker').datepicker({
            dateFormat: 'dd/mm/yy',
            changeMonth: true,
            changeYear: true,
            yearRange: '1900:' + new Date().getFullYear(),
            maxDate: new Date(),
            showButtonPanel: true
        });
    }

    // Initial datepicker setup
    initializeDatepickers();

    // Membership class prices
    const membershipPrices = {
        'ordinary-25': 25,
        'senior-20': 20,
        'junior-15': 15,
        'associate-10': 10,
        'associate-junior-5': 5,
        'life-500': 500,
        'associate-life-250': 250,
        'senior-life-200': 200,
        'associate-senior-life-400': 400
    };

    // Update amount when membership class is selected (Desktop)
    $(document).on('change', '.membership-class', function() {
        const selectedValue = $(this).val();
        const price = membershipPrices[selectedValue] || 0;
        const amountField = $(this).closest('tr').find('.amount-field');
        amountField.val('£' + price);
        calculateTotal();
    });

    // Update amount when membership class is selected (Mobile)
    $(document).on('change', '.membership-class-mobile', function() {
        const selectedValue = $(this).val();
        const price = membershipPrices[selectedValue] || 0;
        const amountField = $(this).closest('.mobile-member-card').find('.amount-field-mobile');
        amountField.val('£' + price);
        calculateTotal();
    });

    // Calculate total amount
    function calculateTotal() {
        let total = 0;

        // Sum up all desktop membership amounts
        $('.amount-field').each(function() {
            const value = $(this).val().replace('£', '');
            const amount = parseFloat(value) || 0;
            total += amount;
        });

        // Sum up all mobile membership amounts
        $('.amount-field-mobile').each(function() {
            const value = $(this).val().replace('£', '');
            const amount = parseFloat(value) || 0;
            total += amount;
        });

        // Add donation if any
        const donation = parseFloat($('#donationAmount').val()) || 0;
        total += donation;

        // Update total display
        $('#totalAmount').text(total.toFixed(2));
    }

    // Recalculate total when donation changes
    $('#donationAmount').on('input', function() {
        calculateTotal();
    });

    // Add another member row (Desktop)
    $('#addMemberBtn').on('click', function() {
        if ($(window).width() >= 768) {
            // Desktop: Add table row
            const newRow = `
                <tr class="member-row">
                    <td><input type="text" class="form-control form-control-sm" name="title[]" placeholder="Mr"></td>
                    <td><input type="text" class="form-control form-control-sm" name="initials[]" placeholder="J"></td>
                    <td><input type="text" class="form-control form-control-sm" name="forename[]" placeholder="John"></td>
                    <td><input type="text" class="form-control form-control-sm" name="surname[]" placeholder="Smith"></td>
                    <td><input type="text" class="form-control form-control-sm datepicker" name="dob[]" placeholder="DD/MM/YYYY"></td>
                    <td>
                        <select class="form-select form-select-sm membership-class" name="membershipClass[]">
                            <option value="">Select...</option>
                            <option value="ordinary-25">Ordinary Member</option>
                            <option value="senior-20">Senior (over 65)</option>
                            <option value="junior-15">Junior (under 21)</option>
                            <option value="associate-10">Associate</option>
                            <option value="associate-junior-5">Associate Junior</option>
                            <option value="life-500">Life Member</option>
                            <option value="associate-life-250">Associate Life</option>
                            <option value="senior-life-200">Senior Life</option>
                            <option value="associate-senior-life-400">Associate Senior Life</option>
                        </select>
                    </td>
                    <td><input type="text" class="form-control form-control-sm" name="membershipCode[]" placeholder="Code"></td>
                    <td><input type="text" class="form-control form-control-sm amount-field" name="amount[]" placeholder="£0" readonly></td>
                </tr>
            `;
            $('#memberTableBody').append(newRow);
        } else {
            // Mobile: Add card-based form
            const newCard = `
                <div class="mobile-member-card" style="margin-top: 20px; border-top: 3px solid #00577B; padding-top: 15px;">
                    <div class="mobile-field-group">
                        <div class="mobile-field-header">Title</div>
                        <input type="text" class="form-control mobile-input" name="mobile_title[]" placeholder="">
                    </div>
                    <div class="mobile-field-group">
                        <div class="mobile-field-header">Initials</div>
                        <input type="text" class="form-control mobile-input" name="mobile_initials[]" placeholder="">
                    </div>
                    <div class="mobile-field-group">
                        <div class="mobile-field-header">Forename</div>
                        <input type="text" class="form-control mobile-input" name="mobile_forename[]" placeholder="">
                    </div>
                    <div class="mobile-field-group">
                        <div class="mobile-field-header">Surname</div>
                        <input type="text" class="form-control mobile-input" name="mobile_surname[]" placeholder="">
                    </div>
                    <div class="mobile-field-group">
                        <div class="mobile-field-header">Date of Birth</div>
                        <input type="text" class="form-control mobile-input datepicker" name="mobile_dob[]" placeholder="">
                    </div>
                    <div class="mobile-field-group">
                        <div class="mobile-field-header">Membership Class</div>
                        <select class="form-select mobile-input membership-class-mobile" name="mobile_membershipClass[]">
                            <option value="">Select...</option>
                            <option value="ordinary-25">Ordinary Member</option>
                            <option value="senior-20">Senior (over 65)</option>
                            <option value="junior-15">Junior (under 21)</option>
                            <option value="associate-10">Associate</option>
                            <option value="associate-junior-5">Associate Junior</option>
                            <option value="life-500">Life Member</option>
                            <option value="associate-life-250">Associate Life</option>
                            <option value="senior-life-200">Senior Life</option>
                            <option value="associate-senior-life-400">Associate Senior Life</option>
                        </select>
                    </div>
                    <div class="mobile-field-group">
                        <div class="mobile-field-header">Amount</div>
                        <input type="text" class="form-control mobile-input amount-field-mobile" name="mobile_amount[]" placeholder="£0" readonly>
                    </div>
                </div>
            `;
            $('#mobileCardContainer').append(newCard);
        }
        
        initializeDatepickers(); // Re-initialize datepickers for new row/card
    });

    // Step navigation
    function showStep(stepNumber) {
        // Hide all steps
        $('.form-step').removeClass('active');
        
        // Show current step
        $(`#step${stepNumber}`).addClass('active');
        
        // Update progress bar
        $('.progress-step').removeClass('active completed');
        
        for (let i = 1; i <= stepNumber; i++) {
            if (i < stepNumber) {
                $(`.progress-step[data-step="${i}"]`).addClass('completed');
            } else if (i === stepNumber) {
                $(`.progress-step[data-step="${i}"]`).addClass('active');
            }
        }
        
        // Scroll to top
        $('html, body').animate({ scrollTop: 0 }, 300);
        
        currentStep = stepNumber;
    }

    // Validate Step 1
    function validateStep1() {
        let isValid = true;
        let errorMessage = '';

        // Check desktop view
        if ($(window).width() >= 768) {
            // Desktop validation
            const memberRows = $('.member-row').length;
            if (memberRows === 0) {
                errorMessage = 'Please add at least one member.';
                isValid = false;
            }

            $('.member-row').each(function(index) {
                const title = $(this).find('input[name="title[]"]').val().trim();
                const forename = $(this).find('input[name="forename[]"]').val().trim();
                const surname = $(this).find('input[name="surname[]"]').val().trim();
                const membershipClass = $(this).find('.membership-class').val();

                if (!title || !forename || !surname || !membershipClass) {
                    errorMessage = `Please fill in all required fields for member ${index + 1}.`;
                    isValid = false;
                    return false;
                }
            });
        } else {
            // Mobile validation
            const mobileCards = $('.mobile-member-card').length;
            if (mobileCards === 0) {
                errorMessage = 'Please add at least one member.';
                isValid = false;
            }

            $('.mobile-member-card').each(function(index) {
                const title = $(this).find('input[name="mobile_title[]"]').val().trim();
                const forename = $(this).find('input[name="mobile_forename[]"]').val().trim();
                const surname = $(this).find('input[name="mobile_surname[]"]').val().trim();
                const membershipClass = $(this).find('.membership-class-mobile').val();

                if (!title || !forename || !surname || !membershipClass) {
                    errorMessage = `Please fill in all required fields for member ${index + 1}.`;
                    isValid = false;
                    return false;
                }
            });
        }

        // Check if total is greater than 0
        const total = parseFloat($('#totalAmount').text());
        if (total <= 0) {
            errorMessage = 'Please select at least one membership class with a valid amount.';
            isValid = false;
        }

        if (!isValid) {
            alert(errorMessage);
        }

        return isValid;
    }

    // Validate Step 2
    function validateStep2() {
        let isValid = true;
        let errorMessage = '';

        const requiredFields = [
            { id: '#ddTitle', name: 'Title' },
            { id: '#ddFirstName', name: 'First name' },
            { id: '#ddLastName', name: 'Last name' },
            { id: '#ddContactNumber', name: 'Contact number' },
            { id: '#ddEmail', name: 'Email address' },
            { id: '#ddConfirmEmail', name: 'Confirm email address' },
            { id: '#ddPostcode', name: 'Postcode' },
            { id: '#ddAddress1', name: 'Address line 1' },
            { id: '#ddTown', name: 'Town' },
            { id: '#ddAccountHolder', name: 'Account holder name' },
            { id: '#sortCode1', name: 'Sort code' },
            { id: '#sortCode2', name: 'Sort code' },
            { id: '#sortCode3', name: 'Sort code' },
            { id: '#ddAccountNumber', name: 'Account number' }
        ];

        for (let field of requiredFields) {
            const value = $(field.id).val().trim();
            if (!value) {
                errorMessage = `Please fill in the ${field.name} field.`;
                isValid = false;
                $(field.id).addClass('is-invalid');
                break;
            } else {
                $(field.id).removeClass('is-invalid').addClass('is-valid');
            }
        }

        if (isValid) {
            const email = $('#ddEmail').val().trim();
            const confirmEmail = $('#ddConfirmEmail').val().trim();
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (!emailRegex.test(email)) {
                errorMessage = 'Please enter a valid email address.';
                isValid = false;
                $('#ddEmail').addClass('is-invalid');
            } else if (email !== confirmEmail) {
                errorMessage = 'Email addresses do not match.';
                isValid = false;
                $('#ddConfirmEmail').addClass('is-invalid');
            }
        }

        if (isValid) {
            const phone = $('#ddContactNumber').val().trim();
            const phoneRegex = /^[\d\s\-\+\(\)]+$/;
            if (!phoneRegex.test(phone) || phone.length < 10) {
                errorMessage = 'Please enter a valid contact number.';
                isValid = false;
                $('#ddContactNumber').addClass('is-invalid');
            }
        }

        if (isValid) {
            const accountNumber = $('#ddAccountNumber').val().trim();
            if (!/^\d{8}$/.test(accountNumber)) {
                errorMessage = 'Account number must be 8 digits.';
                isValid = false;
                $('#ddAccountNumber').addClass('is-invalid');
            }
        }

        if (isValid) {
            const sortCode1 = $('#sortCode1').val().trim();
            const sortCode2 = $('#sortCode2').val().trim();
            const sortCode3 = $('#sortCode3').val().trim();

            if (!/^\d{2}$/.test(sortCode1) || !/^\d{2}$/.test(sortCode2) || !/^\d{2}$/.test(sortCode3)) {
                errorMessage = 'Sort code must be 6 digits (2 digits in each box).';
                isValid = false;
                $('#sortCode1, #sortCode2, #sortCode3').addClass('is-invalid');
            }
        }

        if (!isValid) {
            alert(errorMessage);
        }

        return isValid;
    }

    // Step 1 Next
    $('#step1Next').on('click', function() {
        if (validateStep1()) {
            showStep(2);
        }
    });

    // Step 2 Previous
    $('#step2Prev').on('click', function() {
        showStep(1);
    });

    // Step 2 Next
    $('#step2Next').on('click', function() {
        if (validateStep2()) {
            $(this).addClass('btn-loading').text('Processing...');
            
            setTimeout(function() {
                showStep(3);
                $('#step2Next').removeClass('btn-loading').text('Check Out');
            }, 1500);
        }
    });

    // Auto-fill title field on validation
    $('#ddTitle').on('blur', function() {
        const value = $(this).val().trim();
        if (value) {
            $(this).addClass('is-valid');
        }
    });

    // Sort code auto-advance
    $('#sortCode1, #sortCode2').on('input', function() {
        if ($(this).val().length === 2) {
            $(this).next('.sort-code-separator').next('input').focus();
        }
    });

    // Format sort code input (numbers only)
    $('.sort-code-box').on('input', function() {
        this.value = this.value.replace(/[^\d]/g, '');
    });

    // Format account number (numbers only)
    $('#ddAccountNumber').on('input', function() {
        this.value = this.value.replace(/[^\d]/g, '');
    });

    // Clear validation errors on input
    $('input, select').on('input change', function() {
        $(this).removeClass('is-invalid');
    });

    // Postcode uppercase
    $('#ddPostcode').on('input', function() {
        this.value = this.value.toUpperCase();
    });

    // Prevent form submission on Enter key
    $('#membershipForm').on('keypress', function(e) {
        if (e.which === 13) {
            e.preventDefault();
            return false;
        }
    });

    // Add smooth animation to amount field updates
    $(document).on('change', '.membership-class, .membership-class-mobile', function() {
        const amountField = $(this).closest('tr, .mobile-member-card').find('.amount-field, .amount-field-mobile');
        amountField.css({
            'transition': 'all 0.3s ease',
            'transform': 'scale(1.05)'
        });
        
        setTimeout(function() {
            amountField.css('transform', 'scale(1)');
        }, 300);
    });

    // Gift Aid checkbox animation
    $('#giftAidCheckbox').on('change', function() {
        if ($(this).is(':checked')) {
            $(this).parent().css({
                'background-color': '#e8f5e9',
                'padding': '10px',
                'border-radius': '4px',
                'transition': 'all 0.3s ease'
            });
        } else {
            $(this).parent().css({
                'background-color': 'transparent',
                'padding': '0'
            });
        }
    });

    // Renewal checkbox styling
    $('#renewalCheckbox').on('change', function() {
        if ($(this).is(':checked')) {
            $(this).next('label').css({
                'color': '#c41e3a',
                'font-weight': '600'
            });
        } else {
            $(this).next('label').css({
                'color': '#c41e3a',
                'font-weight': '500'
            });
        }
    });

    // Console log for debugging
    console.log('Membership Form v2 initialized successfully');
    
    // Check if on mobile and show landing screen by default
    if ($(window).width() < 768) {
        $('.landing-screen').addClass('active');
        $('.form-container').removeClass('active');
    } else {
        $('.landing-screen').removeClass('active');
        $('.form-container').addClass('active');
    }
    
    // Initial total calculation
    calculateTotal();
});
