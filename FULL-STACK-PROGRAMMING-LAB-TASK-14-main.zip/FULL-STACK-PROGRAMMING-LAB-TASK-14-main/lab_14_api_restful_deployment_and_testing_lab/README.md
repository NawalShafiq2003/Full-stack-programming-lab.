# Lab 13 — API RESTful Deployment and Testing

This project represents a fully functional Full Stack (MERN) patient management registry integrated with external weather and news APIs. It incorporates JSON Web Token (JWT) authorization, bcrypt password hashing, and user role separation (Admin vs. Standard User).

---

## 🛠️ Technologies Used

- **Backend**: Node.js, Express.js, MongoDB + Mongoose, JWT, bcryptjs, dotenv, cors, nodemon
- **Frontend**: React.js, Axios, React Router DOM, Vanilla CSS (Modern Dark Mode & Glassmorphic theme)
- **Documentation**: `docx` library for compiling report in Word format (.docx), Postman Collection v2.1.0

---

## 📂 Project Structure

```text
lab_13_api_restful_deployment_and_testing_lab/
├── backend/                  # REST API Server
├── frontend/                 # Vite + React Client App
├── documentation/            # Report compiling assets & Postman Collection
└── README.md                 # Project Setup & Guide
```

---

## ⚙️ Environment Variables Setup

Create a `.env` file inside the `backend/` directory and populate it with the following keys:

```env
PORT=5000
NEWS_API_KEY=YOUR_NEWS_API_KEY
OPENWEATHER_API_KEY=YOUR_OPENWEATHER_API_KEY
JWT_SECRET=YOUR_SECRET
MONGO_URI=YOUR_MONGODB_URI
```

*Note: Valid keys for OpenWeather and NewsAPI have already been preset for immediate use.*

---

## 🚀 Execution & Setup Guide

### 1. Prerequisite: Boot MongoDB Database
Ensure that your local MongoDB server is running. You can check this by launching **MongoDB Compass** and connecting to `mongodb://127.0.0.1:27017`.

### 2. Backend Setup
1. Open your terminal and change directory to `backend/`.
2. Install node dependencies:
   ```bash
   npm install
   ```
3. Boot the API server in development mode (using nodemon):
   ```bash
   npm run dev
   ```
   The backend will start listening on `http://localhost:5000`.

### 3. Frontend Setup
1. Open a separate terminal and change directory to `frontend/`.
2. Install node dependencies:
   ```bash
   npm install
   ```
3. Start the Vite React development server:
   ```bash
   npm run dev
   ```
   The application will boot at `http://localhost:5173`. Open this URL in your web browser.

### 4. Document Compilation
To compile the official report for academic submission:
1. Navigate to the `documentation/` folder in your terminal.
2. Ensure you have run `npm install`.
3. Generate the report:
   ```bash
   node generate_docx.js
   ```
   This will compile and output `Lab_13_Report.docx` in the `documentation/` folder.

---

## 🔗 REST API Endpoints

| HTTP Method | Endpoint | Access Control | Description |
|---|---|---|---|
| **POST** | `/api/auth/register` | Public | Sign up user account (username, password, role) |
| **POST** | `/api/auth/login` | Public | Verify credentials; returns JWT token (15-min expiry) |
| **GET** | `/api/patients` | Protected (User/Admin) | Fetch list of all patient records |
| **GET** | `/api/patients/:id` | Protected (User/Admin) | Retrieve single patient record by MongoDB ID |
| **POST** | `/api/patients` | Protected (Admin Only) | Register a new patient document |
| **PUT** | `/api/patients/:id` | Protected (Admin Only) | Edit attributes of a patient record |
| **DELETE** | `/api/patients/:id` | Protected (Admin Only) | Permanently remove a patient record from DB |
| **GET** | `/api/weather/:city` | Protected (User/Admin) | Query weather proxy (OpenWeather API integration) |
| **GET** | `/api/news/:country` | Protected (User/Admin) | Fetch top 10 news headlines (NewsAPI integration) |

---

## 🧪 Postman & Visual Testing

### Postman Collections
1. Open Postman.
2. Click **Import** and select the file `documentation/postman_collection.json`.
3. Use the collection to test the auth routes first.
4. Logging in as a user automatically stores the token inside Postman global environment, which secures succeeding CRUD, weather, and news calls.

### Browser Testing Flow
1. Open `http://localhost:5173/` in your browser.
2. **Register & Login as Admin**:
   - Register a user with the **Administrator** role.
   - Log in. You will redirect to the **Patients** dashboard.
   - Fill in the registry form to insert new patient documents. Try editing and deleting records.
3. **Register & Login as Standard User**:
   - Register a second account with the **Standard User** role.
   - Log in. You will notice the patient dashboard renders a read-only list with no insert forms or delete buttons.
4. **Weather Forecast Lookup**:
   - Navigate to the **Weather** tab.
   - Input a city name (e.g., `London` or `Tokyo`) and click search to fetch live atmospheric metrics.
5. **News Aggregator**:
   - Navigate to the **News** tab.
   - Choose a region code (e.g. `United States`, `United Kingdom`, or `India`) to pull top regional news cards.
