const axios = require('axios');

// @desc    Get top headlines for a country
// @route   GET /api/news/:country
// @access  Private
const getNews = async (req, res) => {
  try {
    const { country } = req.params;
    const apiKey = process.env.NEWS_API_KEY;

    if (!apiKey || apiKey === 'YOUR_KEY') {
      return res.status(500).json({
        success: false,
        message: 'NewsAPI Key is missing or invalid on the server'
      });
    }

    // Country codes validation (must be a 2 letter code, e.g. us, pk, in, gb)
    if (!/^[a-zA-Z]{2}$/.test(country)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid country code. Please use a 2-letter ISO country code (e.g. us, gb, pk)'
      });
    }

    const url = `https://newsapi.org/v2/top-headlines?country=${country.toLowerCase()}&apiKey=${apiKey}`;
    const response = await axios.get(url);

    const articles = response.data.articles || [];
    
    // Map articles to return only 5 to 10 articles, with fields: title, source, url, publishedAt
    const mappedArticles = articles.slice(0, 10).map(article => ({
      title: article.title,
      source: article.source ? article.source.name : 'Unknown Source',
      url: article.url,
      publishedAt: article.publishedAt
    }));

    return res.json({
      success: true,
      count: mappedArticles.length,
      data: mappedArticles
    });
  } catch (error) {
    if (error.response) {
      return res.status(error.response.status).json({
        success: false,
        message: error.response.data.message || 'API failure retrieving news'
      });
    }
    return res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  getNews
};
