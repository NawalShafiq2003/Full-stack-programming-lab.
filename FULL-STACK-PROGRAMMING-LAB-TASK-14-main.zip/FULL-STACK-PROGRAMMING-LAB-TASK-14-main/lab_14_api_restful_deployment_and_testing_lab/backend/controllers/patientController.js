const Patient = require('../models/Patient');

// @desc    Get all patients
// @route   GET /api/patients
// @access  Private
const getPatients = async (req, res) => {
  try {
    const patients = await Patient.find({});
    return res.json({ success: true, count: patients.length, data: patients });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get patient by ID
// @route   GET /api/patients/:id
// @access  Private
const getPatientById = async (req, res) => {
  try {
    const patient = await Patient.findById(req.params.id);

    if (patient) {
      return res.json({ success: true, data: patient });
    } else {
      return res.status(404).json({ success: false, message: 'Patient not found' });
    }
  } catch (error) {
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Patient not found' });
    }
    return res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Create a patient
// @route   POST /api/patients
// @access  Private/Admin
const createPatient = async (req, res) => {
  try {
    const { name, age, disease, contact } = req.body;

    if (!name || !age || !disease || !contact) {
      return res.status(400).json({ success: false, message: 'Please provide all patient details (name, age, disease, contact)' });
    }

    const patient = await Patient.create({
      name,
      age,
      disease,
      contact
    });

    return res.status(201).json({ success: true, data: patient });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Update a patient
// @route   PUT /api/patients/:id
// @access  Private/Admin
const updatePatient = async (req, res) => {
  try {
    const { name, age, disease, contact } = req.body;

    const patient = await Patient.findById(req.params.id);

    if (patient) {
      patient.name = name !== undefined ? name : patient.name;
      patient.age = age !== undefined ? age : patient.age;
      patient.disease = disease !== undefined ? disease : patient.disease;
      patient.contact = contact !== undefined ? contact : patient.contact;

      const updatedPatient = await patient.save();
      return res.json({ success: true, data: updatedPatient });
    } else {
      return res.status(404).json({ success: false, message: 'Patient not found' });
    }
  } catch (error) {
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Patient not found' });
    }
    return res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Delete a patient
// @route   DELETE /api/patients/:id
// @access  Private/Admin
const deletePatient = async (req, res) => {
  try {
    const patient = await Patient.findById(req.params.id);

    if (patient) {
      await patient.deleteOne();
      return res.json({ success: true, message: 'Patient removed successfully' });
    } else {
      return res.status(404).json({ success: false, message: 'Patient not found' });
    }
  } catch (error) {
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Patient not found' });
    }
    return res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  getPatients,
  getPatientById,
  createPatient,
  updatePatient,
  deletePatient
};
