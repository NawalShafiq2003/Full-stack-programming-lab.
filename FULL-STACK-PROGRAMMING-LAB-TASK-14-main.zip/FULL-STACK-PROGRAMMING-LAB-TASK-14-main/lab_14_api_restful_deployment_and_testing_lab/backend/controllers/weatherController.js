const axios = require('axios');

// @desc    Get live weather forecast for a city
// @route   GET /api/weather/:city
// @access  Private
const getWeather = async (req, res) => {
  try {
    const { city } = req.params;
    const apiKey = process.env.OPENWEATHER_API_KEY;

    if (!apiKey || apiKey === 'YOUR_KEY') {
      return res.status(500).json({
        success: false,
        message: 'OpenWeather API Key is missing or invalid on the server'
      });
    }

    const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&units=metric&appid=${apiKey}`;
    const response = await axios.get(url);
    
    const { data } = response;
    return res.json({
      success: true,
      data: {
        city: data.name,
        temperature: data.main.temp,
        condition: data.weather[0].main,
        description: data.weather[0].description,
        humidity: data.main.humidity
      }
    });
  } catch (error) {
    if (error.response) {
      if (error.response.status === 404) {
        return res.status(404).json({ success: false, message: 'City not found' });
      }
      return res.status(error.response.status).json({ success: false, message: error.response.data.message || 'API failure' });
    }
    return res.status(500).json({ success: false, message: error.message });
  }
};

module.exports = {
  getWeather
};
