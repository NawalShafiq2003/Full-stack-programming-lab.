const mongoose = require('mongoose');

const patientSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Please add a patient name'],
    trim: true
  },
  age: {
    type: Number,
    required: [true, 'Please add patient age']
  },
  disease: {
    type: String,
    required: [true, 'Please add a disease diagnosis'],
    trim: true
  },
  contact: {
    type: String,
    required: [true, 'Please add contact details'],
    trim: true
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Patient', patientSchema);
