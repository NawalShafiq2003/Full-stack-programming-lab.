import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';

const Navbar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const token = localStorage.getItem('token');
  const username = localStorage.getItem('username');
  const role = localStorage.getItem('role');

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    localStorage.removeItem('role');
    navigate('/login');
  };

  if (!token) return null;

  return (
    <nav className="glass-card" style={{
      margin: '20px 20px 0 20px',
      borderRadius: 'var(--border-radius-sm)',
      padding: '15px 30px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      borderBottom: '1px solid var(--card-border)',
      zIndex: 10
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        <span style={{
          fontSize: '1.4rem',
          fontWeight: 800,
          background: 'linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent'
        }}>
          MedCore Portal
        </span>
        {role && (
          <span className={`badge badge-${role}`} style={{ fontSize: '0.65rem' }}>
            {role}
          </span>
        )}
      </div>

      <div style={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
        <Link 
          to="/patients" 
          style={{
            fontWeight: 500,
            color: location.pathname === '/patients' ? 'var(--primary-hover)' : 'var(--text-muted)',
            transition: 'color var(--transition-fast)'
          }}
        >
          Patients
        </Link>
        <Link 
          to="/weather" 
          style={{
            fontWeight: 500,
            color: location.pathname === '/weather' ? 'var(--secondary-hover)' : 'var(--text-muted)',
            transition: 'color var(--transition-fast)'
          }}
        >
          Weather
        </Link>
        <Link 
          to="/news" 
          style={{
            fontWeight: 500,
            color: location.pathname === '/news' ? 'var(--primary-hover)' : 'var(--text-muted)',
            transition: 'color var(--transition-fast)'
          }}
        >
          News
        </Link>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
        <span style={{ fontSize: '0.9rem', color: 'var(--text-muted)', fontWeight: 500 }}>
          Hi, <span style={{ color: 'var(--text-primary)', fontWeight: 600 }}>{username}</span>
        </span>
        <button 
          onClick={handleLogout} 
          className="btn btn-secondary btn-small"
          style={{ padding: '8px 16px' }}
        >
          Logout
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
