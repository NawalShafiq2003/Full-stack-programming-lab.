import React, { useState } from 'react';
import axios from 'axios';

const News = () => {
  const [country, setCountry] = useState('us');
  const [articles, setArticles] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const token = localStorage.getItem('token');

  const fetchNews = async (e) => {
    if (e) e.preventDefault();
    if (!country) return;

    setError('');
    setArticles([]);
    setLoading(true);

    try {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`
        }
      };
      const response = await axios.get(`http://localhost:5000/api/news/${country}`, config);
      setArticles(response.data.data || []);
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.message || 'Failed to fetch news headlines. Verify NewsAPI key.');
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    fetchNews();
  }, [country]);

  const formatDate = (dateString) => {
    if (!dateString) return '';
    const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <div className="main-content animate-fade-in">
      <div style={{ marginBottom: '30px', display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: '20px' }}>
        <div>
          <h1 style={{ fontSize: '2.5rem', fontWeight: 800, background: 'linear-gradient(135deg, #ffffff 0%, var(--text-muted) 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            Latest Global Headlines
          </h1>
          <p style={{ color: 'var(--text-muted)', marginTop: '5px' }}>
            Top curated articles synchronized live from NewsAPI
          </p>
        </div>

        {/* Country Selector */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', minWidth: '220px' }}>
          <label className="form-label" style={{ margin: 0, whiteSpace: 'nowrap' }}>Region:</label>
          <select 
            className="form-select" 
            value={country} 
            onChange={(e) => setCountry(e.target.value)}
            style={{ width: 'auto', flex: 1 }}
          >
            <option value="us">United States (US)</option>
            <option value="gb">United Kingdom (GB)</option>
            <option value="in">India (IN)</option>
            <option value="ca">Canada (CA)</option>
            <option value="au">Australia (AU)</option>
            <option value="nz">New Zealand (NZ)</option>
            <option value="ae">United Arab Emirates (AE)</option>
            <option value="za">South Africa (ZA)</option>
          </select>
        </div>
      </div>

      {error && (
        <div style={{ background: 'rgba(239, 68, 68, 0.15)', border: '1px solid rgba(239, 68, 68, 0.3)', color: '#fca5a5', padding: '12px 16px', borderRadius: 'var(--border-radius-sm)', marginBottom: '30px' }}>
          {error}
        </div>
      )}

      {loading ? (
        <div style={{ textAlign: 'center', padding: '50px', color: 'var(--text-muted)' }}>
          Retrieving live feed...
        </div>
      ) : articles.length === 0 ? (
        <div className="glass-card" style={{ padding: '50px', textAlign: 'center', color: 'var(--text-muted)' }}>
          No articles returned for this country code.
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {articles.map((article, idx) => (
            <div 
              key={idx} 
              className="glass-card animate-fade-in" 
              style={{ 
                padding: '25px', 
                borderRadius: 'var(--border-radius-md)',
                display: 'flex',
                flexDirection: 'column',
                gap: '12px',
                borderLeft: '4px solid var(--primary)',
                animationDelay: `${idx * 0.05}s`
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '10px' }}>
                <span className="badge badge-user" style={{ background: 'rgba(139, 92, 246, 0.12)', color: 'var(--primary-hover)' }}>
                  {article.source}
                </span>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>
                  {formatDate(article.publishedAt)}
                </span>
              </div>

              <h3 style={{ fontSize: '1.25rem', color: '#ffffff', fontWeight: 600, lineHeight: '1.4' }}>
                {article.title}
              </h3>

              <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '10px' }}>
                <a 
                  href={article.url} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="btn btn-secondary btn-small"
                  style={{ 
                    display: 'inline-flex', 
                    alignItems: 'center', 
                    gap: '6px', 
                    fontSize: '0.8rem',
                    padding: '8px 16px'
                  }}
                >
                  Read Full Article ↗
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default News;
