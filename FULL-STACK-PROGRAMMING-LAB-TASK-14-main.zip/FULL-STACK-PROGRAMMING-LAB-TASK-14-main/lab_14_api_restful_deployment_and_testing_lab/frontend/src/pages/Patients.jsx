import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Patients = () => {
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Form states
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [disease, setDisease] = useState('');
  const [contact, setContact] = useState('');
  
  // Edit mode states
  const [editingId, setEditingId] = useState(null);
  const [editName, setEditName] = useState('');
  const [editAge, setEditAge] = useState('');
  const [editDisease, setEditDisease] = useState('');
  const [editContact, setEditContact] = useState('');

  const token = localStorage.getItem('token');
  const role = localStorage.getItem('role');
  const isAdmin = role === 'admin';

  // Axios config
  const config = {
    headers: {
      Authorization: `Bearer ${token}`
    }
  };

  const fetchPatients = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await axios.get('http://localhost:5000/api/patients', config);
      setPatients(response.data.data || []);
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.message || 'Failed to fetch patients.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPatients();
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    if (!name || !age || !disease || !contact) {
      setError('Please fill in all fields.');
      return;
    }

    try {
      const payload = { name, age: Number(age), disease, contact };
      await axios.post('http://localhost:5000/api/patients', payload, config);
      
      setSuccess('Patient registered successfully!');
      setName('');
      setAge('');
      setDisease('');
      setContact('');
      fetchPatients();
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.message || 'Failed to create patient.');
    }
  };

  const handleUpdate = async (id) => {
    setError('');
    setSuccess('');
    
    if (!editName || !editAge || !editDisease || !editContact) {
      setError('Please fill in all fields for updating.');
      return;
    }

    try {
      const payload = { name: editName, age: Number(editAge), disease: editDisease, contact: editContact };
      await axios.put(`http://localhost:5000/api/patients/${id}`, payload, config);
      
      setSuccess('Patient records updated!');
      setEditingId(null);
      fetchPatients();
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.message || 'Failed to update patient.');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this patient record?')) return;
    setError('');
    setSuccess('');
    try {
      await axios.delete(`http://localhost:5000/api/patients/${id}`, config);
      setSuccess('Patient record deleted successfully.');
      fetchPatients();
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.message || 'Failed to delete patient.');
    }
  };

  const startEdit = (patient) => {
    setEditingId(patient._id);
    setEditName(patient.name);
    setEditAge(patient.age);
    setEditDisease(patient.disease);
    setEditContact(patient.contact);
  };

  return (
    <div className="main-content animate-fade-in">
      <div style={{ marginBottom: '30px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h1 style={{ fontSize: '2.5rem', fontWeight: 800, background: 'linear-gradient(135deg, #ffffff 0%, var(--text-muted) 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            Patient Management Registry
          </h1>
          <p style={{ color: 'var(--text-muted)', marginTop: '5px' }}>
            {isAdmin ? 'Complete records management workspace' : 'View patient records (Read-Only access)'}
          </p>
        </div>
      </div>

      {error && (
        <div style={{ background: 'rgba(239, 68, 68, 0.15)', border: '1px solid rgba(239, 68, 68, 0.3)', color: '#fca5a5', padding: '12px 16px', borderRadius: 'var(--border-radius-sm)', marginBottom: '20px' }}>
          {error}
        </div>
      )}

      {success && (
        <div style={{ background: 'rgba(16, 185, 129, 0.15)', border: '1px solid rgba(16, 185, 129, 0.3)', color: '#a7f3d0', padding: '12px 16px', borderRadius: 'var(--border-radius-sm)', marginBottom: '20px' }}>
          {success}
        </div>
      )}

      <div className="grid-2" style={{ alignItems: 'start', gridTemplateColumns: isAdmin ? '1fr 2fr' : '1fr' }}>
        {/* Registration Form for Admin */}
        {isAdmin && (
          <div className="glass-card" style={{ padding: '30px', borderRadius: 'var(--border-radius-md)' }}>
            <h3 style={{ fontSize: '1.25rem', marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--primary-hover)' }}>
              Add Patient Record
            </h3>
            <form onSubmit={handleCreate}>
              <div className="form-group">
                <label className="form-label">Full Name</label>
                <input
                  type="text"
                  className="form-input"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. John Doe"
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Age</label>
                <input
                  type="number"
                  className="form-input"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  placeholder="e.g. 45"
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Diagnosed Disease</label>
                <input
                  type="text"
                  className="form-input"
                  value={disease}
                  onChange={(e) => setDisease(e.target.value)}
                  placeholder="e.g. Hypertension"
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Contact Details</label>
                <input
                  type="text"
                  className="form-input"
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                  placeholder="e.g. +1 (555) 019-2834"
                  required
                />
              </div>

              <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '10px' }}>
                Add Patient
              </button>
            </form>
          </div>
        )}

        {/* Patients Registry List */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div className="glass-card" style={{ padding: '20px 30px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontWeight: 600, fontSize: '1.1rem' }}>Active Patient Records</span>
            <span className="badge badge-user" style={{ background: 'rgba(255,255,255,0.05)', color: 'var(--text-muted)' }}>
              Total: {patients.length}
            </span>
          </div>

          {loading ? (
            <div style={{ textAlign: 'center', padding: '40px', color: 'var(--text-muted)' }}>Loading registry...</div>
          ) : patients.length === 0 ? (
            <div className="glass-card" style={{ padding: '40px', textAlign: 'center', color: 'var(--text-muted)' }}>
              No patient records found in the database.
            </div>
          ) : (
            <div className="grid-3" style={{ gridTemplateColumns: isAdmin ? 'repeat(2, 1fr)' : 'repeat(3, 1fr)', gap: '20px' }}>
              {patients.map((patient) => (
                <div key={patient._id} className="glass-card" style={{ padding: '24px', position: 'relative', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', height: '100%', minHeight: '260px' }}>
                  {editingId === patient._id ? (
                    /* Edit mode form */
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', height: '100%' }}>
                      <input 
                        type="text" 
                        className="form-input" 
                        style={{ padding: '6px 10px', fontSize: '0.9rem' }}
                        value={editName} 
                        onChange={(e) => setEditName(e.target.value)}
                        placeholder="Name" 
                      />
                      <input 
                        type="number" 
                        className="form-input" 
                        style={{ padding: '6px 10px', fontSize: '0.9rem' }}
                        value={editAge} 
                        onChange={(e) => setEditAge(e.target.value)}
                        placeholder="Age" 
                      />
                      <input 
                        type="text" 
                        className="form-input" 
                        style={{ padding: '6px 10px', fontSize: '0.9rem' }}
                        value={editDisease} 
                        onChange={(e) => setEditDisease(e.target.value)}
                        placeholder="Disease" 
                      />
                      <input 
                        type="text" 
                        className="form-input" 
                        style={{ padding: '6px 10px', fontSize: '0.9rem' }}
                        value={editContact} 
                        onChange={(e) => setEditContact(e.target.value)}
                        placeholder="Contact" 
                      />
                      
                      <div style={{ display: 'flex', gap: '10px', marginTop: 'auto', paddingTop: '10px' }}>
                        <button 
                          onClick={() => handleUpdate(patient._id)} 
                          className="btn btn-primary btn-small"
                          style={{ flex: 1 }}
                        >
                          Save
                        </button>
                        <button 
                          onClick={() => setEditingId(null)} 
                          className="btn btn-secondary btn-small"
                          style={{ flex: 1 }}
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    /* Normal card display */
                    <>
                      <div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '15px' }}>
                          <h4 style={{ fontSize: '1.2rem', color: '#ffffff' }}>{patient.name}</h4>
                          <span className="badge badge-user" style={{ fontSize: '0.7rem' }}>Age: {patient.age}</span>
                        </div>
                        
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '20px' }}>
                          <div>
                            <span style={{ fontSize: '0.75rem', textTransform: 'uppercase', color: 'var(--text-dim)', display: 'block', fontWeight: 600 }}>DIAGNOSIS</span>
                            <span style={{ fontSize: '0.95rem', color: 'var(--text-primary)' }}>{patient.disease}</span>
                          </div>
                          <div>
                            <span style={{ fontSize: '0.75rem', textTransform: 'uppercase', color: 'var(--text-dim)', display: 'block', fontWeight: 600 }}>CONTACT</span>
                            <span style={{ fontSize: '0.9rem', color: 'var(--text-muted)' }}>{patient.contact}</span>
                          </div>
                        </div>
                      </div>
                      
                      {isAdmin && (
                        <div style={{ display: 'flex', gap: '10px', borderTop: '1px solid rgba(255,255,255,0.06)', paddingTop: '15px', marginTop: 'auto' }}>
                          <button 
                            onClick={() => startEdit(patient)} 
                            className="btn btn-secondary btn-small"
                            style={{ flex: 1 }}
                          >
                            Edit
                          </button>
                          <button 
                            onClick={() => handleDelete(patient._id)} 
                            className="btn btn-danger btn-small"
                            style={{ flex: 1 }}
                          >
                            Delete
                          </button>
                        </div>
                      )}
                    </>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Patients;
