import React, { useState } from 'react';
import axios from 'axios';

const Weather = () => {
  const [city, setCity] = useState('');
  const [weatherData, setWeatherData] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const token = localStorage.getItem('token');

  const fetchWeather = async (e) => {
    e.preventDefault();
    if (!city.trim()) return;

    setError('');
    setWeatherData(null);
    setLoading(true);

    try {
      const config = {
        headers: {
          Authorization: `Bearer ${token}`
        }
      };
      const response = await axios.get(`http://localhost:5000/api/weather/${encodeURIComponent(city.trim())}`, config);
      setWeatherData(response.data.data);
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.message || 'Failed to fetch weather forecast. Ensure API keys are active.');
    } finally {
      setLoading(false);
    }
  };

  const getWeatherEmoji = (condition) => {
    if (!condition) return '🌡️';
    const cond = condition.toLowerCase();
    if (cond.includes('cloud')) return '☁️';
    if (cond.includes('rain') || cond.includes('drizzle')) return '🌧️';
    if (cond.includes('clear') || cond.includes('sun')) return '☀️';
    if (cond.includes('snow')) return '❄️';
    if (cond.includes('thunder')) return '⛈️';
    if (cond.includes('mist') || cond.includes('fog') || cond.includes('haze')) return '🌫️';
    return '🌡️';
  };

  return (
    <div className="main-content animate-fade-in" style={{ maxWidth: '600px' }}>
      <div style={{ marginBottom: '30px', textAlign: 'center' }}>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 800, background: 'linear-gradient(135deg, #ffffff 0%, var(--text-muted) 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
          Live Weather Forecast
        </h1>
        <p style={{ color: 'var(--text-muted)', marginTop: '5px' }}>
          Query real-time meteorological conditions via OpenWeather API
        </p>
      </div>

      <div className="glass-card" style={{ padding: '30px', borderRadius: 'var(--border-radius-md)', marginBottom: '30px' }}>
        <form onSubmit={fetchWeather} style={{ display: 'flex', gap: '15px' }}>
          <div style={{ flex: 1 }}>
            <input
              type="text"
              className="form-input"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="Enter city name (e.g. London, Islamabad, New York)"
              required
            />
          </div>
          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? 'Searching...' : 'Search'}
          </button>
        </form>
      </div>

      {error && (
        <div style={{ background: 'rgba(239, 68, 68, 0.15)', border: '1px solid rgba(239, 68, 68, 0.3)', color: '#fca5a5', padding: '12px 16px', borderRadius: 'var(--border-radius-sm)', marginBottom: '20px', textAlign: 'center' }}>
          {error}
        </div>
      )}

      {weatherData && (
        <div className="glass-card animate-fade-in" style={{ 
          padding: '40px', 
          borderRadius: 'var(--border-radius-lg)', 
          textAlign: 'center',
          background: 'linear-gradient(135deg, rgba(20, 18, 33, 0.7) 0%, rgba(139, 92, 246, 0.1) 100%)',
          border: '1px solid rgba(139, 92, 246, 0.2)',
          boxShadow: 'var(--glass-shadow), 0 0 30px rgba(139, 92, 246, 0.15)'
        }}>
          <div style={{ fontSize: '5rem', marginBottom: '10px' }}>
            {getWeatherEmoji(weatherData.condition)}
          </div>
          
          <h2 style={{ fontSize: '2.2rem', marginBottom: '5px', color: '#ffffff' }}>
            {weatherData.city}
          </h2>
          
          <p style={{ 
            fontSize: '1.1rem', 
            color: 'var(--secondary)', 
            fontWeight: 600, 
            textTransform: 'uppercase', 
            letterSpacing: '0.1em',
            marginBottom: '25px'
          }}>
            {weatherData.description}
          </p>

          <div style={{ 
            display: 'flex', 
            justifyContent: 'space-around', 
            borderTop: '1px solid rgba(255, 255, 255, 0.08)',
            paddingTop: '25px'
          }}>
            <div>
              <span style={{ fontSize: '0.85rem', color: 'var(--text-dim)', textTransform: 'uppercase', display: 'block', fontWeight: 600, marginBottom: '5px' }}>
                TEMPERATURE
              </span>
              <span style={{ fontSize: '1.8rem', fontWeight: 700, color: '#ffffff' }}>
                {weatherData.temperature}°C
              </span>
            </div>
            
            <div style={{ borderLeft: '1px solid rgba(255,255,255,0.08)' }}></div>
            
            <div>
              <span style={{ fontSize: '0.85rem', color: 'var(--text-dim)', textTransform: 'uppercase', display: 'block', fontWeight: 600, marginBottom: '5px' }}>
                HUMIDITY
              </span>
              <span style={{ fontSize: '1.8rem', fontWeight: 700, color: '#ffffff' }}>
                {weatherData.humidity}%
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Weather;
